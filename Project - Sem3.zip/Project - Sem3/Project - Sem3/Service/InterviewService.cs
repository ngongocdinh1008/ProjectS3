﻿using Microsoft.EntityFrameworkCore;
using Project___Sem3.Dto;
using Project___Sem3.Entity;
using Project___Sem3.Entity.Admin;

namespace Project___Sem3.Service
{
    public class InterviewService
    {
        private readonly AppDbContext _context;

        public InterviewService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Interview> CreateInterviewWithPositionsAsync(InterviewDto interviewDto)
        {
            // Tạo thực thể Interview từ DTO
            var interview = new Interview
            {
                Title = interviewDto.Title,
                Address = interviewDto.Address,
                InterviewEndDate = interviewDto.InterviewEndDate,
                WorkingHours = interviewDto.WorkingHours,
                Positions = new List<Position>()
            };

            // Tạo danh sách Position từ PositionDto
            foreach (var positionDto in interviewDto.Positions)
            {
                var position = new Position
                {
                    PositionTitle = positionDto.PositionTitle,
                    Salary = positionDto.Salary,
                    ExperienceRequired = positionDto.ExperienceRequired,
                    Rank = positionDto.Rank,
                    JobType = positionDto.JobType,
                    GenderRequirement = positionDto.GenderRequirement,
                    Interview = interview // Liên kết với Interview
                };

                // Thêm Position vào danh sách Positions của Interview
                interview.Positions.Add(position);
            }

            // Thêm Interview và các Positions vào DbContext
            _context.Interviews.Add(interview);
            await _context.SaveChangesAsync();

            return interview;
        }

        public async Task<Interview> GetInterviewByIdAsync(int id)
        {
            return await _context.Interviews
                .FirstOrDefaultAsync(i => i.InterviewId == id);  
        }
        public async Task AddJobDescriptionAsync(JobDescriptionDto jobDescriptionDto)
        {
            var interview = await _context.Interviews.FindAsync(jobDescriptionDto.InterviewId);
            if (interview == null) throw new Exception("Interview not found");

            var jobDescription = new JobDescription
            {
                Description = jobDescriptionDto.Description,
                InterviewId = jobDescriptionDto.InterviewId
            };

            _context.JobDescriptions.Add(jobDescription);
            await _context.SaveChangesAsync();
        }
        public async Task AddCandidateRequirementAsync(CandidateRequirementDto candidateRequirementDto)
        {
            var interview = await _context.Interviews.FindAsync(candidateRequirementDto.InterviewId);
            if (interview == null) throw new Exception("Interview not found");

            var candidateRequirement = new CandidateRequirement
            {
                Requirement = candidateRequirementDto.Requirement,
                InterviewId = candidateRequirementDto.InterviewId
            };

            _context.CandidateRequirements.Add(candidateRequirement);
            await _context.SaveChangesAsync();
        }

        // Thêm Position vào Interview đã tồn tại
        public async Task AddPositionAsync(PositionDto positionDto)
        {
            var interview = await _context.Interviews.FindAsync(positionDto.InterviewId);
            if (interview == null) throw new Exception("Interview not found");

            var position = new Position
            {
                PositionTitle = positionDto.PositionTitle,
                Salary = positionDto.Salary,
                ExperienceRequired = positionDto.ExperienceRequired,
                Rank = positionDto.Rank,
                JobType = positionDto.JobType,
                GenderRequirement = positionDto.GenderRequirement,
                InterviewId = positionDto.InterviewId
            };

            _context.Positions.Add(position);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateInterviewAsync(int interviewId, UpdateInterviewDto updateDto)
        {
            var interview = await _context.Interviews.FindAsync(interviewId);
            if (interview == null) throw new Exception("Interview not found");

            bool isModified = false;

            // Kiểm tra và cập nhật từng thuộc tính nếu giá trị mới khác với giá trị hiện tại
            if (interview.Title != updateDto.Title)
            {
                interview.Title = updateDto.Title;
                isModified = true;
            }

            if (interview.Address != updateDto.Address)
            {
                interview.Address = updateDto.Address;
                isModified = true;
            }

            if (interview.InterviewEndDate != updateDto.InterviewEndDate)
            {
                interview.InterviewEndDate = updateDto.InterviewEndDate;
                isModified = true;
            }

            if (interview.WorkingHours != updateDto.WorkingHours)
            {
                interview.WorkingHours = updateDto.WorkingHours;
                isModified = true;
            }

            // Chỉ lưu thay đổi nếu có bất kỳ thuộc tính nào được sửa
            if (isModified)
            {
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No changes detected");
            }
        }
        // Phương thức xóa Interview và các bảng liên quan
        public async Task DeleteInterviewAsync(int interviewId)
        {
            var interview = await _context.Interviews
                .Include(i => i.Positions)
                .Include(i => i.JobDescriptions)
                .Include(i => i.CandidateRequirements)
                .FirstOrDefaultAsync(i => i.InterviewId == interviewId);

            if (interview == null)
            {
                throw new Exception("Interview not found");
            }

            // Xóa Interview (các Position, JobDescription và CandidateRequirement sẽ bị xóa theo nhờ cascade delete)
            _context.Interviews.Remove(interview);
            await _context.SaveChangesAsync();
        }
    }
}
