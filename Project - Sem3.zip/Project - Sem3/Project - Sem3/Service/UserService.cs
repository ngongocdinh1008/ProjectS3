﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Project___Sem3.Dto;
using Project___Sem3.Entity;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
namespace Project___Sem3.Service
{
    public class UserService
    {
        private readonly AppDbContext _context;
        private readonly EmailService _emailService;
        private readonly IConfiguration _configuration;

        public UserService(AppDbContext context, EmailService emailService, IConfiguration configuration)
        {
            _context = context;
            _emailService = emailService;
            _configuration = configuration;
        }

        public async Task RegisterUserAsync(UserCreateDto model)
        {
            // Kiểm tra xem các thuộc tính trong model có giá trị hay không
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Email) ||
                string.IsNullOrEmpty(model.Password) || string.IsNullOrEmpty(model.ConfirmPassword))
            {
                throw new ArgumentException("Các trường thông tin không được để trống.");
            }

            // Kiểm tra xem ConfirmPassword có khớp với Password không
            if (model.Password != model.ConfirmPassword)
            {
                throw new ArgumentException("Password và Confirm Password không khớp.");
            }

            // Kiểm tra xem email đã tồn tại chưa
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == model.Email);
            if (existingUser != null)
            {
                if (existingUser.IsVerified)
                {
                    throw new ArgumentException("Email này đã được sử dụng để đăng ký tài khoản và đã xác nhận.");
                }
                else
                {
                    // Nếu email chưa xác nhận, gửi lại email xác nhận
                    await SendVerificationEmail(existingUser);
                    throw new ArgumentException("Email này đã tồn tại nhưng chưa được xác nhận. Email xác nhận đã được gửi lại.");
                }
            }

            // Hash mật khẩu người dùng
            var hashedPassword = HashPassword(model.Password);

            // Tạo người dùng mới
            var user = new User
            {
                UserName = model.Username,
                Email = model.Email,
                Password = hashedPassword,
                IsVerified = false,
                VerificationCode = Guid.NewGuid().ToString(), // Tạo mã xác thực ngẫu nhiên
                Role = "User"
            };

            // Thêm người dùng vào cơ sở dữ liệu
            _context.Users.Add(user);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                // Ghi lại thông tin lỗi để kiểm tra nguyên nhân cụ thể
                Console.WriteLine($"Lỗi khi lưu dữ liệu: {ex.InnerException?.Message}");
                throw new Exception("Có lỗi xảy ra khi lưu dữ liệu vào cơ sở dữ liệu. Vui lòng thử lại.");
            }

            // Gửi email xác nhận
            await SendVerificationEmail(user);
        }

        private async Task SendVerificationEmail(User user)
        {
            // Gửi email với đường link xác nhận
            string body = $"Vui lòng nhấn vào liên kết sau để xác nhận tài khoản của bạn: " +
                          $"https://localhost:44350/api/User/verify?code={user.VerificationCode}";

            // Gọi EmailService để gửi email
            await _emailService.SendEmailAsync(user.Email, "Xác nhận tài khoản của bạn", body);
        }

        private string HashPassword(string password)
        {
            // Hàm hash mật khẩu (ví dụ dùng BCrypt hoặc SHA256)
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        public async Task<bool> VerifyEmailAsync(string verificationCode)
        {
            // Kiểm tra xem mã xác thực có hợp lệ không
            var user = await _context.Users.FirstOrDefaultAsync(u => u.VerificationCode == verificationCode);
            if (user == null)
            {
                throw new Exception("Mã xác thực không hợp lệ.");
            }

            // Xác thực người dùng và cập nhật trạng thái
            user.IsVerified = true;
            user.VerificationCode = ""; // Đảm bảo giá trị không phải là null
            _context.Users.Update(user);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"Lỗi khi cập nhật dữ liệu: {ex.InnerException?.Message}");
                throw new Exception("Có lỗi xảy ra khi cập nhật dữ liệu trong cơ sở dữ liệu. Vui lòng thử lại.");
            }

            return true;
        }
        public async Task<bool> ForgotPasswordAsync(string email)
        {
            // Tìm người dùng theo email
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                throw new Exception("Email không tồn tại.");
            }

            // Tạo mật khẩu mới
            string newPassword = GenerateRandomPassword(6);
            user.Password = HashPassword(newPassword);

            // Gửi email với mật khẩu mới
            var emailService = new EmailService(_configuration);
            string body = $"Mật khẩu mới của bạn là: {newPassword}";

            try
            {
                await emailService.SendEmailAsync(user.Email, "Mật khẩu mới", body);
            }
            catch (Exception ex)
            {
                throw new Exception("Không thể gửi email. Vui lòng thử lại.");
            }

            // Lưu mật khẩu mới vào cơ sở dữ liệu
            try
            {
                _context.Users.Update(user);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                throw new Exception("Có lỗi xảy ra khi lưu mật khẩu mới vào cơ sở dữ liệu. Vui lòng thử lại.");
            }

            return true;
        }
        private string GenerateRandomPassword(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public async Task<string> LoginAsync(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user == null)
            {
                throw new Exception("Tài khoản không tồn tại.");
            }

            bool isPasswordValid = BCrypt.Net.BCrypt.Verify(password, user.Password);
            if (!isPasswordValid)
            {
                throw new Exception("Mật khẩu không chính xác.");
            }

            if (!user.IsVerified)
            {
                throw new Exception("Tài khoản chưa được xác minh.");
            }

            // Tạo token JWT cho người dùng
            return GenerateJwtToken(user);
        }
        private string GenerateJwtToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["JwtSettings:SecretKey"]); // Khóa bí mật được lấy từ appsettings.json
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role) // Lấy role từ user
            }),
                Expires = DateTime.UtcNow.AddHours(2), // Token sẽ hết hạn sau 2 giờ
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}