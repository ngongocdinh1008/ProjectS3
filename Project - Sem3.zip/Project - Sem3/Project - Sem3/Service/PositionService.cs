﻿using Project___Sem3.Dto;
using Project___Sem3.Entity;

namespace Project___Sem3.Service
{
    public class PositionService
    {
        private readonly AppDbContext _context;

        public PositionService(AppDbContext context)
        {
            _context = context;
        }

        // Cập nhật thông tin của Position
        public async Task UpdatePositionAsync(int positionId, UpdatePositionDto updateDto)
        {
            var position = await _context.Positions.FindAsync(positionId);
            if (position == null) throw new Exception("Position not found");

            bool isModified = false;

            // Kiểm tra và cập nhật từng thuộc tính nếu giá trị mới khác với giá trị hiện tại
            if (position.PositionTitle != updateDto.PositionTitle)
            {
                position.PositionTitle = updateDto.PositionTitle;
                isModified = true;
            }

            if (position.Salary != updateDto.Salary)
            {
                position.Salary = updateDto.Salary;
                isModified = true;
            }

            if (position.ExperienceRequired != updateDto.ExperienceRequired)
            {
                position.ExperienceRequired = updateDto.ExperienceRequired;
                isModified = true;
            }

            if (position.Rank != updateDto.Rank)
            {
                position.Rank = updateDto.Rank;
                isModified = true;
            }

            if (position.JobType != updateDto.JobType)
            {
                position.JobType = updateDto.JobType;
                isModified = true;
            }

            if (position.GenderRequirement != updateDto.GenderRequirement)
            {
                position.GenderRequirement = updateDto.GenderRequirement;
                isModified = true;
            }

            // Chỉ lưu thay đổi nếu có bất kỳ thuộc tính nào được sửa
            if (isModified)
            {
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No changes detected");
            }
        }
        // Phương thức xóa Position dựa trên PositionId
        public async Task DeletePositionAsync(int positionId)
        {
            var position = await _context.Positions.FindAsync(positionId);
            if (position == null)
            {
                throw new Exception("Position not found");
            }

            _context.Positions.Remove(position);
            await _context.SaveChangesAsync();
        }
    }
}
