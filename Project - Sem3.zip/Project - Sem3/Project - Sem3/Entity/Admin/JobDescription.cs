﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Entity.Admin
{
    public class JobDescription
    {
        [Key]
        public int JobDescriptionId { get; set; }

        [Required]
        [MaxLength(5000)] // Để lưu trữ nội dung mô tả công việc
        public string Description { get; set; }

        // Khóa ngoại liên kết đến bảng Interview
        public int InterviewId { get; set; }

        // Navigation Property liên kết với bảng Interview
        public Interview Interview { get; set; }
    }
}
