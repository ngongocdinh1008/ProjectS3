﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Project___Sem3.Entity.Admin
{
    public class Position
    {
        [Key] // Khóa chính tự động tăng
        public int PositionId { get; set; }

        [Required]
        [MaxLength(100)] // Tên vị trí tuyển dụng
        public string PositionTitle { get; set; }

        [Required] // Mức lương
        public decimal Salary { get; set; }

        [Required] // Kinh nghiệm (số năm kinh nghiệm yêu cầu)
        public int ExperienceRequired { get; set; }

        [MaxLength(50)] // Cấp bậc (Junior, Senior, etc.)
        public string Rank { get; set; }

        [MaxLength(50)] // Hình thức làm việc (Full-time, Part-time, etc.)
        public string JobType { get; set; }

        [MaxLength(100)] // Giới tính yêu cầu (Nam, Nữ, Không yêu cầu)
        public string GenderRequirement { get; set; }

        // Khóa ngoại liên kết đến bảng Interview
        public int InterviewId { get; set; }

        // Navigation Property liên kết với bảng Interview
        [JsonIgnore]
        public Interview Interview { get; set; }

    }
}
