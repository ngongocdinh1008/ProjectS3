﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Entity
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username phải có độ dài từ 3 đến 50 ký tự.")]
        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "Username chỉ chứa ký tự chữ và số.")]
        public string UserName { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password phải có ít nhất 6 ký tự.")]
        public string Password { get; set; }

        [RegularExpression(@"^(\+84|0)\d{9,10}$", ErrorMessage = "Số điện thoại không hợp lệ.")]
        public string? PhoneNumber { get; set; }

        public string? Address { get; set; }

        public bool IsVerified { get; set; } = false;

        public string? VerificationCode { get; set; }

        public string Role { get; set; } = "User";
    }
}
