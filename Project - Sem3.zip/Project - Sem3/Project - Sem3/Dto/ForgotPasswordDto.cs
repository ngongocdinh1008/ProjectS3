﻿namespace Project___Sem3.Dto
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
