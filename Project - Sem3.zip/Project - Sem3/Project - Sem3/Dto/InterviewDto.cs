﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class InterviewDto
    {
        // Tiêu đề cuộc phỏng vấn
        [Required(ErrorMessage = "Tiêu đề là bắt buộc.")]
        [MaxLength(200, ErrorMessage = "Tiêu đề không được vượt quá 200 ký tự.")]
        public string Title { get; set; }

        // Địa chỉ cuộc phỏng vấn
        [Required(ErrorMessage = "Địa chỉ là bắt buộc.")]
        [MaxLength(200, ErrorMessage = "Địa chỉ không được vượt quá 200 ký tự.")]
        public string Address { get; set; }

        // Hạn kết thúc cuộc phỏng vấn
        [Required(ErrorMessage = "Hạn kết thúc là bắt buộc.")]
        public DateTime InterviewEndDate { get; set; }

        // Thời gian làm việc
        [Required(ErrorMessage = "Thời gian làm việc là bắt buộc.")]
        [MaxLength(100, ErrorMessage = "Thời gian làm việc không được vượt quá 100 ký tự.")]
        public string WorkingHours { get; set; }

        public List<PositionDto> Positions { get; set; } = new List<PositionDto>();
    }
}
    