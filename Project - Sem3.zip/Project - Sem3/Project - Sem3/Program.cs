﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Project___Sem3.Entity;
using Project___Sem3.Service;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Cấu hình các dịch vụ (DI container)
builder.Services.AddControllers();

// Cấu hình CORS nếu cần (ví dụ khi bạn dùng API từ frontend)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes("YOUR_SECRET_KEY")), // Thay YOUR_SECRET_KEY bằng khóa bí mật của bạn
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

// Thêm Swagger/OpenAPI để hỗ trợ tài liệu API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Cấu hình DbContext sử dụng SQL Server
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));

// Đăng ký các dịch vụ khác cần thiết cho ứng dụng
builder.Services.AddScoped<InterviewService>();
builder.Services.AddScoped<PositionService>();
builder.Services.AddScoped<CandidateRequirementService>();
builder.Services.AddScoped<JobDescriptionService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<EmailService>();

var app = builder.Build();

// Cấu hình middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
else
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Áp dụng CORS
app.UseCors("AllowAll");
app.UseHttpsRedirection();

app.MapControllers();

app.Run();
