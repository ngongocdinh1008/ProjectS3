﻿using Microsoft.AspNetCore.Mvc;
using Project___Sem3.Dto;
using Project___Sem3.Service;
using System.Threading.Tasks;

namespace Project_Sem3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
        {
            try
            {
                var token = await _userService.LoginAsync(loginDto.Email, loginDto.Password);
                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] UserCreateDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _userService.RegisterUserAsync(model);
                return Ok("Email xác nhận đã được gửi.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Có lỗi xảy ra khi đăng ký người dùng: " + ex.Message);
            }
        }

        [HttpGet("verify")]
        public async Task<IActionResult> VerifyEmail(string code)
        {
            try
            {
                bool result = await _userService.VerifyEmailAsync(code);
                if (result)
                {
                    return Ok("Tài khoản đã được xác nhận thành công.");
                }
                else
                {
                    return BadRequest("Mã xác thực không hợp lệ.");
                }
            }
            catch (Exception ex)
            {
                // Kiểm tra xem có lỗi bên trong (InnerException) không, nếu có thì log lại chi tiết
                var errorMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;

                // Log lỗi vào console (có thể thay bằng ghi log file hoặc sử dụng công cụ log)
                Console.WriteLine($"Chi tiết lỗi: {errorMessage}");

                // Trả về BadRequest với chi tiết lỗi
                return BadRequest($"Đã xảy ra lỗi: {errorMessage}");
            }
        }
        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordDto forgotPasswordDto)
        {
            try
            {
                var result = await _userService.ForgotPasswordAsync(forgotPasswordDto.Email);
                if (result)
                {
                    return Ok("Mật khẩu mới đã được gửi tới email của bạn.");
                }
                else
                {
                    return BadRequest("Email không tồn tại.");
                }
            }
            catch (Exception ex)
            {
                // Ghi lại lỗi chi tiết vào log
                Console.WriteLine($"Đã xảy ra lỗi: {ex.Message}");
                Console.WriteLine($"Chi tiết lỗi: {ex.StackTrace}");

                // Nếu cần, bạn có thể thêm thông tin nội dung lỗi vào 'InnerException'
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Lỗi bên trong: {ex.InnerException.Message}");
                }

                // Trả về thông báo lỗi chi tiết cho API
                return BadRequest(new { message = "Đã xảy ra lỗi, vui lòng kiểm tra log để biết thêm chi tiết.", error = ex.Message });
            }
        }

    }
}
