﻿using Microsoft.AspNetCore.Mvc;
using Project___Sem3.Dto;
using Project___Sem3.Service;

namespace Project___Sem3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PositionController : ControllerBase
    {
        private readonly PositionService _positionService;

        public PositionController(PositionService positionService)
        {
            _positionService = positionService;
        }

        // API để cập nhật thông tin Position
        [HttpPut("update-position/{id}")]
        public async Task<IActionResult> UpdatePosition(int id, [FromBody] UpdatePositionDto updateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _positionService.UpdatePositionAsync(id, updateDto);
                return Ok("Position updated successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        // API để xóa Position dựa trên PositionId
        [HttpDelete("delete-position/{id}")]
        public async Task<IActionResult> DeletePosition(int id)
        {
            try
            {
                await _positionService.DeletePositionAsync(id);
                return Ok("Position deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
