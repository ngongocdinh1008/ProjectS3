﻿using Microsoft.AspNetCore.Mvc;
using Project___Sem3.Dto;
using Project___Sem3.Service;

namespace Project___Sem3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CandidateRequirementController : ControllerBase
    {
        private readonly CandidateRequirementService _candidateRequirementService;

        public CandidateRequirementController(CandidateRequirementService candidateRequirementService)
        {
            _candidateRequirementService = candidateRequirementService;
        }

        [HttpPut("update-candidate-requirement/{id}")]
        public async Task<IActionResult> UpdateCandidateRequirement(int id, [FromBody] UpdateCandidateRequirementDto updateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _candidateRequirementService.UpdateCandidateRequirementAsync(id, updateDto);
                return Ok("Candidate Requirement updated successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        // API để xóa CandidateRequirement dựa trên CandidateRequirementId
        [HttpDelete("delete-candidate-requirement/{id}")]
        public async Task<IActionResult> DeleteCandidateRequirement(int id)
        {
            try
            {
                await _candidateRequirementService.DeleteCandidateRequirementAsync(id);
                return Ok("Candidate Requirement deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
